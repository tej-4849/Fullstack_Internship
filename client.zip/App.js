import React, { useState, useEffect } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

function App() {
  const [text, setText] = useState("");

  useEffect(() => {
    socket.on("documentUpdated", setText);
    return () => socket.off("documentUpdated");
  }, []);

  const handleChange = (e) => {
    setText(e.target.value);
    socket.emit("updateDocument", { content: e.target.value });
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Real-Time Collaborative Editor</h2>
      <textarea
        rows="20"
        cols="80"
        value={text}
        onChange={handleChange}
      />
    </div>
  );
}

export default App;
