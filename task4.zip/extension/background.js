// background.js
// simplified version for zip
console.log('Background running');